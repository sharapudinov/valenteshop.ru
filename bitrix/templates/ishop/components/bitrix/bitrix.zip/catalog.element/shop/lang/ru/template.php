<?
$MESS["CATALOG_ADD_TO_BASKET"] = "В корзину";
$MESS["CATALOG_IZB"] = "В избранное";
$MESS["CATALOG_ADD_TO_BASKET_IN"] = "В корзину";
$MESS["CATALOG_MORE_PHOTO"] = "Еще фото";
$MESS["CATALOG_DOWNLOAD"] = "Скачать";
$MESS["CATALOG_BACK"] = "Назад в раздел";
$MESS["CATALOG_BUY"] = "В корзину";
$MESS["ARTICLE"] = "Артикул:";
$MESS["CATALOG_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CATALOG_ORDER_NAME"] = "Оповестить о наличии";
$MESS["CATALOG_QUANTITY"] = "Количество";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "От #FROM# до #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "От #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "До #TO#";
$MESS["CATALOG_PRICE_VAT"] = "с НДС";
$MESS["CATALOG_PRICE_NOVAT"] = "без НДС";
$MESS["CATALOG_VAT"] = "НДС";
$MESS["CATALOG_NO_VAT"] = "не облагается";
$MESS["CATALOG_VAT_INCLUDED"] = "НДС включен в цену";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "НДС не включен в цену";
$MESS["CT_BCE_QUANTITY"] = "Количество";
$MESS["CT_BCE_CATALOG_ADD"] = "В корзину";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Сравнить";
$MESS["CT_BCE_CATALOG_IZB"] = "Отложить";
$MESS["CT_BCE_CATALOG_FIND_CHEAPER"] = "Нашли дешевле?";
$MESS["CT_BCE_CATALOG_DOP_DESCR"] = "Дополнительное описание элемента";
$MESS["CT_BCE_CATALOG_SOC_BUTTON"] = "Кнопки социальных сетей";

$MESS["CT_NAME_CHARACTERISTIC"] = "Описание";
$MESS["CT_NAME_REVIEW"] = "Отзывы, вопросы";
$MESS["CT_NAME_STORES"] = "Склады";
$MESS["CT_NAME_IN_STORES"] = "Наличие в магазинах";
$MESS["CT_NAME_INSTRUCTIONS"] = "Документы";
$MESS["CT_NAME_DOP_OBORUDOVANIE"] = "Аксессуары";
$MESS["CT_NAME_DOP_CHAR"] = "Характеристики";

$MESS["CT_NAME_SIZE"] = "Размер";
$MESS["CT_NAME_GB"] = " Гб";
$MESS["CT_NAME_MB"] = " Мб";
$MESS["CT_NAME_KB"] = " Кб";
$MESS["CT_NAME_b"] = " байт";

$MESS["CATALOG_FROM"] = "от";
$MESS["CATALOG_PRICE"] = "Цена";
$MESS["NOT_PROP"] = "Не задано";

$MESS['CT_IS_AVAILABLE'] = "Есть в наличии";
$MESS['AVAILABLE'] = "В наличии";
$MESS['MEASURE'] = "шт.";
$MESS['CATALOG_IN_CART'] = "В корзине";

$MESS["CT_NAME_ASSOCIATED_TITLE"] = "С товаром часто покупают:";
$MESS["ONE_CLICK_BUY"] = "Купить в 1 клик";
$MESS["BRAND"] = "Производитель";
?>