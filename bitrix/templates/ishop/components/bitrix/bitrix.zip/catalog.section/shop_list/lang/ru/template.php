<?
$MESS["CATALOG_BUY"] = "Купить";
$MESS["CATALOG_ADD_TO_BASKET"] = "В корзину";
$MESS["CATALOG_IN_CART"] = "В корзине";
$MESS["CATALOG_ADD_IN"] = "В корзину";
$MESS["CATALOG_COMPARE"] = "Сравнить";
$MESS["CATALOG_IZB"] = "Добавить в избранное";
$MESS["CATALOG_NOT_AVAILABLE"] = "Нет в наличии";
$MESS["CT_IS_AVAILABLE"] = "Есть в наличии";
$MESS["CATALOG_ORDER"] = "Заказать";
$MESS['CATALOG_ORDER_NAME'] = "Заказать";
$MESS["CATALOG_QUANTITY"] = "Количество";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "От #FROM# до #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "От #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "До #TO#";
$MESS["CT_BCS_QUANTITY"] = "Количество";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";

$MESS['CATALOG_FROM'] = 'от';
$MESS['CATALOG_MORE'] = 'Подробнее';

$MESS["CT_NAME_NOT_FOUND"] = "Товары не найдены";
$MESS["CT_NAME_SHOW_ALL"] = "Показать все";
$MESS["CATALOG_VIEW_MORE"] = "Показать основные";
$MESS["PROPERTIES"] = "Характеристики";
?>