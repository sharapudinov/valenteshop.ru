<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<div class="group_list">
	<?$i = 1;
	foreach($arResult["SECTIONS"] as $arSection){
		$this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], CIBlock::GetArrayByID($arSection["IBLOCK_ID"], "SECTION_EDIT"));
		$this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], CIBlock::GetArrayByID($arSection["IBLOCK_ID"], "SECTION_DELETE"), array("CONFIRM" => GetMessage('CT_BCSL_ELEMENT_DELETE_CONFIRM')));
		?>
		<div class="group_item <?=($i % 4 == 0) ? 'last' : ''?>" id="<?=$this->GetEditAreaId($arSection['ID']);?>">
			<div class="group_item_inner">
				<div class="image">
					<a href="<?=$arSection["SECTION_PAGE_URL"]?>">
						<?if( !empty( $arSection["PICTURE"] ) ){?>
<?$file = CFile::ResizeImageGet($arSection["PICTURE"]["ID"], array('width'=>170, 'height'=>170), BX_RESIZE_IMAGE_PROPORTIONAL, true);?>
							<img style="border-radius: 10px !important;" src="<?=$file["src"]?>" alt="<?=$arSection["NAME"]?>" title="<?=$arSection["NAME"]?>" />
						<?}else{?>
							<img style="border-radius: 10px !important;" src="<?=SITE_TEMPLATE_PATH?>/img/noimage_group.png" alt="<?=$arSection["NAME"]?>" title="<?=$arSection["NAME"]?>" />
						<?}?>
					</a>
				</div>
				<div class="name">
					<a href="<?=$arSection["SECTION_PAGE_URL"]?>">
						<?=$arSection["NAME"]?><?=$arSection["ELEMENT_CNT"]?'&nbsp;('.$arSection["ELEMENT_CNT"].')':'';?>
					</a>
				</div>
			</div>
		</div>
		<?if( $i % 4 == 0 ){?>
			<hr />
		<?}?>
	<?$i++;
	}?>
</div>

<div style="margin-top: 20px;">
	<?=$arResult["SECTION"]["DESCRIPTION"]?>
</div>