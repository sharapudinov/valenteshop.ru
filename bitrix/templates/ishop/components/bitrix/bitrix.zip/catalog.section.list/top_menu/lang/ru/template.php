<?
$MESS["CT_BCSL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["CATALOG_VIEW_MORE"] = "Показать еще";
$MESS["CATALOG_VIEW_LESS"] = "Свернуть";
?>